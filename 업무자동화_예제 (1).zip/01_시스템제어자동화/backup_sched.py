import glob
import shutil

# 절대 경로로 지정
path = 'C:/Users/Lenovo/업무자동화/01_시스템제어자동화/'

# word 파일 복사
for fname in glob.glob(path + 'origin/*.docx') :
    shutil.copy(fname, path + 'backup')
    
# excel 파일 복사
for fname in glob.glob(path + 'origin/*.xlsx') :
    shutil.copy(fname, path + 'backup')
